///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadTorusMesh();
	m_basicMeshes->LoadConeMesh();

	//load wood texture
	CreateGLTexture("textures/Wood02.png", "wood");

	//load metal texture
	CreateGLTexture("textures/blackMetal.png", "metal");
	
	//load carpet texture
	CreateGLTexture("textures/carpet.png", "carpet");
	// bind loaded textures
	BindGLTextures();

	//Enable lighting
	m_pShaderManager->setIntValue("bUseLighting", true);

	//Directional light coming from above
	m_pShaderManager->setVec3Value("lightSources[0].position", glm::vec3(5.0f, 15.0f, 5.0f));
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", glm::vec3(0.3f, 0.3f, 0.3f));
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", glm::vec3(2.0f, 2.0f, 2.0f));
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", glm::vec3(1.0f, 1.0f, 1.0f));

	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 32.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 1.0f);
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	m_pShaderManager->setIntValue("bUseLighting", true);


	//testing
	m_pShaderManager->setVec3Value("material.ambientColor",
		glm::vec3(0.3f, 0.3f, 0.3f));

	m_pShaderManager->setFloatValue("material.ambientStrength", 0.2f);

	m_pShaderManager->setVec3Value("material.diffuseColor",
		glm::vec3(0.3f, 0.3f, 0.3f));

	m_pShaderManager->setVec3Value("material.specularColor",
		glm::vec3(0.2f, 0.2f, 0.2f));

	m_pShaderManager->setFloatValue("material.shininess", 8.0f);

	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 1.95f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("carpet");
	SetTextureUVScale(8.0f, 8.0f);

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	/****************************************************************/

	//Object 1 - front left leg
	// set XYZ scale for mesh
	scaleXYZ = glm::vec3(.1f, 1.7f, 0.1f);

	//set XYZ rotation for mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	//set XYZ position for mesh
	positionXYZ = glm::vec3(-0.95f, 2.80f, 7.95f);

	//set transformations to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 1.0f);

	//draw the mesh
	m_basicMeshes->DrawBoxMesh();

	//Object 2 - front right leg
	// set XYZ scale for mesh
	scaleXYZ = glm::vec3(.1f, 1.7f, 0.1f);

	//set XYZ rotation for mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	//set XYZ position for mesh
	positionXYZ = glm::vec3(0.95f, 2.80f, 7.95f);

	//set transformations to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 1.0f);

	//draw the mesh
	m_basicMeshes->DrawBoxMesh();

	//Object 3 -  table top
	// set XYZ scale for mesh
	scaleXYZ = glm::vec3(2.0f, 0.1f, 2.0f);

	//set XYZ rotation for mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	//set XYZ position for mesh
	positionXYZ = glm::vec3(0.0f, 4.0f, 7.0f);

	//set transformations to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	//SetShaderColor(0.55f, 0.27f, 0.07f, 1.0f);
	SetShaderTexture("wood");
	SetTextureUVScale(4.0f, 4.0f);

	//draw the mesh
	m_basicMeshes->DrawBoxMesh();

	//Object 4 - back left leg
	// set XYZ scale for mesh
	scaleXYZ = glm::vec3(.1f, 1.7f, 0.1f);

	//set XYZ rotation for mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	//set XYZ position for mesh
	positionXYZ = glm::vec3(-0.95f, 2.80f, 6.05f);

	//set transformations to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 1.0f);

	//draw the mesh
	m_basicMeshes->DrawBoxMesh();

	//Object 5 - back right leg
	// set XYZ scale for mesh
	scaleXYZ = glm::vec3(.1f, 1.7f, 0.1f);

	//set XYZ rotation for mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	//set XYZ position for mesh
	positionXYZ = glm::vec3(0.95f, 2.80f, 6.05f);

	//set transformations to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 1.0f);

	//draw the mesh
	m_basicMeshes->DrawBoxMesh();

	//Object 6 - front left leg support
	// set XYZ scale for mesh
	scaleXYZ = glm::vec3(.08f, 0.35f, 0.08f);

	//set XYZ rotation for mesh
	XrotationDegrees = -25.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	//set XYZ position for mesh
	positionXYZ = glm::vec3(-0.95f, 3.80f, 7.85f);

	//set transformations to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 1.0f);

	//draw the mesh
	m_basicMeshes->DrawBoxMesh();

	//Object 7 - front right leg support
	// set XYZ scale for mesh
	scaleXYZ = glm::vec3(.08f, 0.35f, 0.08f);

	//set XYZ rotation for mesh
	XrotationDegrees = -25.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	//set XYZ position for mesh
	positionXYZ = glm::vec3(0.95f, 3.80f, 7.85f);

	//set transformations to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 1.0f);

	//draw the mesh
	m_basicMeshes->DrawBoxMesh();

	//Object 8 - back left leg support
	// set XYZ scale for mesh
	scaleXYZ = glm::vec3(.08f, 0.35f, 0.08f);

	//set XYZ rotation for mesh
	XrotationDegrees = 25.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	//set XYZ position for mesh
	positionXYZ = glm::vec3(-0.95f, 3.80f, 6.15f);

	//set transformations to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 1.0f);

	//draw the mesh
	m_basicMeshes->DrawBoxMesh();

	//Object 9 - back right leg support
	// set XYZ scale for mesh
	scaleXYZ = glm::vec3(.08f, 0.35f, 0.08f);

	//set XYZ rotation for mesh
	XrotationDegrees = 25.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	//set XYZ position for mesh
	positionXYZ = glm::vec3(0.95f, 3.80f, 6.15f);

	//set transformations to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 1.0f);

	//draw the mesh
	m_basicMeshes->DrawBoxMesh();

	//Object 10 - lower front cross cylinder
	// set XYZ scale for mesh
	scaleXYZ = glm::vec3(.06f, 1.75f, 0.06f);

	//set XYZ rotation for mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f;

	//set XYZ position for mesh
	positionXYZ = glm::vec3(0.875f, 2.375f, 7.95f);

	//set transformations to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 1.0f);

	//draw the mesh
	m_basicMeshes->DrawCylinderMesh();

	//Object 11 - upper front cross cylinder
	// set XYZ scale for mesh
	scaleXYZ = glm::vec3(.06f, 1.75f, 0.06f);

	//set XYZ rotation for mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f;

	//set XYZ position for mesh
	positionXYZ = glm::vec3(0.875f, 3.08f, 7.95f);

	//set transformations to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 1.0f);

	//draw the mesh
	m_basicMeshes->DrawCylinderMesh();

	//Object 12 - lower back cross cylinder
	// set XYZ scale for mesh
	scaleXYZ = glm::vec3(.06f, 1.75f, 0.06f);

	//set XYZ rotation for mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f;

	//set XYZ position for mesh
	positionXYZ = glm::vec3(0.875f, 2.375f, 6.05f);

	//set transformations to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 1.0f);

	//draw the mesh
	m_basicMeshes->DrawCylinderMesh();

	//Object 13 - upper back cross cylinder
	// set XYZ scale for mesh
	scaleXYZ = glm::vec3(.06f, 1.75f, 0.06f);

	//set XYZ rotation for mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f;

	//set XYZ position for mesh
	positionXYZ = glm::vec3(0.875f, 3.08f, 6.05f);

	//set transformations to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 1.0f);

	//draw the mesh
	m_basicMeshes->DrawCylinderMesh();

	//Object 14 -  left cross beam
	// set XYZ scale for mesh
	scaleXYZ = glm::vec3(0.15f, 0.25f, 1.90f);

	//set XYZ rotation for mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	//set XYZ position for mesh
	positionXYZ = glm::vec3(-0.95f, 2.375f, 7.00f);

	//set transformations to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("wood");
	SetTextureUVScale(4.0f, 4.0f);

	//draw the mesh
	m_basicMeshes->DrawBoxMesh();

	//Object 15 -  right cross beam
	// set XYZ scale for mesh
	scaleXYZ = glm::vec3(0.15f, 0.25f, 1.90f);

	//set XYZ rotation for mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	//set XYZ position for mesh
	positionXYZ = glm::vec3(0.95f, 2.375f, 7.00f);

	//set transformations to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("wood");
	SetTextureUVScale(4.0f, 4.0f);

	//draw the mesh
	m_basicMeshes->DrawBoxMesh();

	//Object 16 -  lower shelf
	// set XYZ scale for mesh
	scaleXYZ = glm::vec3(1.75f, 0.03f, 1.80f);

	//set XYZ rotation for mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	//set XYZ position for mesh
	positionXYZ = glm::vec3(0.0f, 2.395f, 7.00f);

	//set transformations to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderColor(0.2f, 0.2f, 0.2f, 0.4f);

	//draw the mesh
	m_basicMeshes->DrawBoxMesh();

	//Object 17 -  upper shelf
	// set XYZ scale for mesh
	scaleXYZ = glm::vec3(1.75f, 0.03f, 1.80f);

	//set XYZ rotation for mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	//set XYZ position for mesh
	positionXYZ = glm::vec3(0.0f, 3.10f, 7.00f);

	//set transformations to be used on the drawn mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderColor(0.2f, 0.2f, 0.2f, 0.4f);

	//draw the mesh
	m_basicMeshes->DrawBoxMesh();

	//Object 18 - lamp base
	scaleXYZ = glm::vec3(0.40f, 0.10f, 0.40f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(0.0f, 4.05f, 6.50f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawCylinderMesh();

	//Object 19 - Lamp Stem
	scaleXYZ = glm::vec3(0.05f, 1.70f, 0.05f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(0.0f, 4.15f, 6.12f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawCylinderMesh();

	//Object 20 - Lamp arm
	scaleXYZ = glm::vec3(0.05f, 0.40f, 0.05f);

	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(0.0f, 5.80f, 6.15f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawCylinderMesh();

	// Object 21 - lamp arm top

	scaleXYZ = glm::vec3(0.07f, 0.20f, 0.07f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(0.0f, 5.7f, 6.50f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawCylinderMesh();

	// Object 22 - lamp socket

	scaleXYZ = glm::vec3(0.15f, 0.20f, 0.15f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(0.0f, 5.5f, 6.50f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawCylinderMesh();

	// Object 23 - lampshade

	scaleXYZ = glm::vec3(0.34f, 0.8f, 0.34f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(0.0f, 4.69f, 6.50f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderColor(0.95f, 0.95f, 0.95f, 0.95f);

	m_basicMeshes->DrawCylinderMesh();

	// Object 24 - lamp switch knob

	scaleXYZ = glm::vec3(0.04f, 0.08f, 0.04f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(0.0f, 4.15f, 6.82f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawCylinderMesh();

	//Object 25 - Ring
	scaleXYZ = glm::vec3(0.04f, 0.04f, 0.05f);

	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(-0.1f, 4.16f, 6.65f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderColor(0.78f, 0.78f, 0.82f, 1.0f);

	m_basicMeshes->DrawTorusMesh();

	//Object 26 - pill bottle
	scaleXYZ = glm::vec3(0.13f, 0.38f, 0.13f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(-0.6f, 4.05f, 6.7f);

	SetTransformations(scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(1.0f, 0.55f, 0.1f, 0.7f);

	m_basicMeshes->DrawCylinderMesh();

	//Object 27 - pill bottle cap
	scaleXYZ = glm::vec3(0.14f, 0.08f, 0.14f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(-0.6f, 4.36f, 6.7f);

	SetTransformations(scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.95f, 0.95f, 0.95f, 1.0f);

	m_basicMeshes->DrawCylinderMesh();

	//Object 28 water bottle
	scaleXYZ = glm::vec3(0.13f, 0.65f, 0.13f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(-0.4f, 4.05f, 7.2f);

	SetTransformations(scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.95f, 0.95f, 1.0f, 0.25f);

	m_basicMeshes->DrawCylinderMesh();

	//Object 29 top of water bottle
	scaleXYZ = glm::vec3(0.13f, 0.25f, 0.13f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(-0.4f, 4.70f, 7.2f);

	SetTransformations(scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.95f, 0.95f, 1.0f, 0.25f);

	m_basicMeshes->DrawConeMesh();

	//Object 30 water bottle cap
	// Object 29 cap (cylinder)
	scaleXYZ = glm::vec3(0.05f, 0.03f, 0.05f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(-0.4f, 4.92f, 7.2f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderColor(0.95f, 0.95f, 1.0f, 1.0f);

	m_basicMeshes->DrawCylinderMesh();

}
