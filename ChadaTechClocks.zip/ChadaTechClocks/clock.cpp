#include "Clock.h"
#include <iostream>
#include <iomanip>
#include <algorithm>
#include <string>
#include <limits>

using namespace std;

Clock::Clock() : hour(0), minute(0), second(0) {}

void Clock::addHour() { //adds an hour to clock, checks if we need to roll over to a new day
    if (hour < 23) hour++;
    else hour = 0;
}

void Clock::addMinute() { //adds a minute to the clock, checks if we need to roll over to the next hour
    if (minute < 59) minute++;
    else {
        minute = 0;
        addHour();
    }
}

void Clock::addSecond() { //adds a second to the clock, checks if we need to roll over to the next minute
    if (second < 59) second++;
    else {
        second = 0;
        addMinute();
    }
}   

void Clock::setTime(int h, int m, int s) {
    hour = (h >= 0 && h < 24) ? h : 0;
    minute = (m >= 0 && m < 60) ? m : 0;
    second = (s >= 0 && s < 60) ? s : 0;
}

void Clock::setInitialTime() { //for setting the initial time on the clock
    int formatChoice; //variable for 12 vs 24 hour for input
    int inputHour;
    int inputMinute;
    int inputSecond;
    string ampm;

    while (true) {
        cout << "Choose time format:\n";
        cout << "1 - 12-hour format\n";
        cout << "2 - 24-hour format\n";
        cout << "Enter choice: ";
        cin >> formatChoice;

        if (cin.fail()) { //handles errors in input
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid input. Please enter 1 or 2.\n\n";
            continue;
        }

        if (formatChoice == 1) {
            // Input hour
            cout << "Enter hours (1-12): ";
            while (true) {
                cin >> inputHour;
                if (cin.fail()) { //handles errors in input
                    cin.clear();
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                    cout << "Invalid input. Enter hours (1-12): ";
                }
                else if (inputHour < 1 || inputHour > 12) {
                    cout << "Invalid input. Enter hours (1-12): ";
                }
                else {
                    break;
                }
            }

            // Input minute
            cout << "Enter minutes (0-59): ";
            while (true) {
                cin >> inputMinute;
                if (cin.fail()) {
                    cin.clear();
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                    cout << "Invalid input. Enter minutes (0-59): ";
                }
                else if (inputMinute < 0 || inputMinute > 59) {
                    cout << "Invalid input. Enter minutes (0-59): ";
                }
                else {
                    break;
                }
            }

            // Input second
            cout << "Enter seconds (0-59): ";
            while (true) {
                cin >> inputSecond;
                if (cin.fail()) {
                    cin.clear();
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                    cout << "Invalid input. Enter seconds (0-59): ";
                }
                else if (inputSecond < 0 || inputSecond > 59) {
                    cout << "Invalid input. Enter seconds (0-59): ";
                }
                else {
                    break;
                }
            }

            // Input AM or PM
            cout << "Enter AM or PM: ";
            while (true) {
                cin >> ampm;
                transform(ampm.begin(), ampm.end(), ampm.begin(), ::toupper);
                if (ampm == "AM" || ampm == "PM") {
                    break;
                }
                else {
                    cout << "Invalid input. Enter AM or PM: ";
                }
            }

            // Convert 12-hour to 24-hour format
            if (ampm == "AM" && inputHour == 12) inputHour = 0;
            else if (ampm == "PM" && inputHour != 12) inputHour += 12;

            break;  // Exit outer while loop after successful input
        }
        else if (formatChoice == 2) {
            // Input hour
            cout << "Enter hours (0-23): ";
            while (true) {
                cin >> inputHour;
                if (cin.fail()) {
                    cin.clear();
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                    cout << "Invalid input. Enter hours (0-23): ";
                }
                else if (inputHour < 0 || inputHour > 23) {
                    cout << "Invalid input. Enter hours (0-23): ";
                }
                else {
                    break;
                }
            }

            // Input minute
            cout << "Enter minutes (0-59): ";
            while (true) {
                cin >> inputMinute;
                if (cin.fail()) {
                    cin.clear();
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                    cout << "Invalid input. Enter minutes (0-59): ";
                }
                else if (inputMinute < 0 || inputMinute > 59) {
                    cout << "Invalid input. Enter minutes (0-59): ";
                }
                else {
                    break;
                }
            }

            // Input second
            cout << "Enter seconds (0-59): ";
            while (true) {
                cin >> inputSecond;
                if (cin.fail()) { //handles errors in input
                    cin.clear();
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                    cout << "Invalid input. Enter seconds (0-59): ";
                }
                else if (inputSecond < 0 || inputSecond > 59) {
                    cout << "Invalid input. Enter seconds (0-59): ";
                }
                else {
                    break;
                }
            }

            break;  // Exit outer while loop after successful input
        }
        else { //handles errors in input
            cout << "Invalid format selection. Please enter 1 or 2.\n\n";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
    }

    setTime(inputHour, inputMinute, inputSecond);
    cout << "Initial time set.\n\n";
}

void Clock::displayTime() const //method for displaying time including required formatting
{
    int displayHour12 = hour % 12;
    if (displayHour12 == 0) displayHour12 = 12;
    string ampm = (hour < 12) ? "AM" : "PM";

    cout << "**************************    **************************\n";
    cout << "*     12-Hour Clock      *    *     24-Hour Clock      *\n";
    cout << "*      "
        << setw(2) << setfill('0') << displayHour12 << ":"
        << setw(2) << setfill('0') << minute << ":"
        << setw(2) << setfill('0') << second << " " << ampm << "       *    *        "
        << setw(2) << setfill('0') << hour << ":"
        << setw(2) << setfill('0') << minute << ":"
        << setw(2) << setfill('0') << second << "        *\n";
    cout << "**************************    **************************\n";
}

