#ifndef CLOCK_H
#define CLOCK_H
#include <string>

class Clock { //declares methods and variables necessary for settings and updating time as well as displaying
private:
    int hour;
    int minute;
    int second;

public:
    Clock();

    void addHour();
    void addMinute();
    void addSecond();

    void setTime(int h, int m, int s);
    void setInitialTime();
    void displayTime() const;
};

#endif