/*
 * File: chadatechclocks.cpp
 * Author: Blake Buhr
 * Date: [07-20-2025]
 * Description: Main file for the Chada Tech Clocks project.
 *              Displays and updates 12-hour and 24-hour clocks
 */

#include <iostream>
#include <string>
#include <limits>
#include "Clock.h"
using namespace std;

void displayMenu() {
    cout << "1 - Add Hour\n";
    cout << "2 - Add Minute\n";
    cout << "3 - Add Second\n";
    cout << "4 - Exit\n";
    cout << "Enter your choice: ";
}

void handleMenuChoice(int choice, Clock& clock) { //cases for the menu options
    switch (choice) {
    case 1: clock.addHour(); break;
    case 2: clock.addMinute(); break;
    case 3: clock.addSecond(); break;
    case 4: cout << "Exiting...\n"; break;
    default: cout << "Invalid choice\n"; break;
    }
    clock.displayTime();
}

int main()
{
    Clock clock; //makes a clock object
    clock.setInitialTime(); //calls to set the time at the beginning of the program
    
    int choice;
    do {
        displayMenu(); //displays menu

        while (!(cin >> choice)) {  //If input fails
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid input. Please enter a number from 1 to 4: ";
        }

        handleMenuChoice(choice, clock); //calls to the menu for handling decisions
    } while (choice != 4);


    return 0;
}

