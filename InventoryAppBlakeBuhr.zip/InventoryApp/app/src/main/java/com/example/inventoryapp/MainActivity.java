package com.example.inventoryapp;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText usernameInput;
    private EditText passwordInput;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.passwordInput);

        Button loginButton = findViewById(R.id.loginButton);
        Button createAccountButton = findViewById(R.id.createAccountButton);

        databaseHelper = new DatabaseHelper(this);

        createAccountButton.setOnClickListener(v -> createAccount());

        loginButton.setOnClickListener(v -> loginUser());
    }

    private void createAccount() {

        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this,
                    "Please enter a username and password.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = databaseHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);

        try {
            long result = db.insertOrThrow("users", null, values);

            if (result != -1) {
                Toast.makeText(this,
                        "Account created successfully.",
                        Toast.LENGTH_SHORT).show();

                usernameInput.setText("");
                passwordInput.setText("");
            }

        } catch (Exception e) {
            Toast.makeText(this,
                    "That username already exists.",
                    Toast.LENGTH_SHORT).show();
        }

        db.close();
    }

    private void loginUser() {

        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this,
                    "Please enter a username and password.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = databaseHelper.getReadableDatabase();

        Cursor cursor = db.query(
                "users",
                new String[]{"id"},
                "username = ? AND password = ?",
                new String[]{username, password},
                null,
                null,
                null
        );

        boolean loginSuccessful = cursor.moveToFirst();

        cursor.close();
        db.close();

        if (loginSuccessful) {

            Toast.makeText(this,
                    "Login successful.",
                    Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(MainActivity.this, InventoryActivity.class);
            startActivity(intent);

        } else {

            Toast.makeText(this,
                    "Invalid username or password.",
                    Toast.LENGTH_SHORT).show();
        }
    }
}