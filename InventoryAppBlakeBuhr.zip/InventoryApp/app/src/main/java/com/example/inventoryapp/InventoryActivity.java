package com.example.inventoryapp;

import android.content.Intent;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.widget.EditText;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.Manifest;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

import androidx.appcompat.app.AppCompatActivity;

public class InventoryActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private TableLayout inventoryTable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        databaseHelper = new DatabaseHelper(this);
        inventoryTable = findViewById(R.id.inventoryTable);

        Button addItemButton = findViewById(R.id.addItemButton);
        addItemButton.setOnClickListener(v -> showAddItemDialog());

        Button smsAlertsButton = findViewById(R.id.smsAlertsButton);
        smsAlertsButton.setOnClickListener(v -> {
            Intent intent = new Intent(InventoryActivity.this,
                    NotificationActivity.class);
            startActivity(intent);
        });

        loadInventory();

    }

    private void loadInventory() {

        SQLiteDatabase db = databaseHelper.getReadableDatabase();

        Cursor cursor = db.query(
                "inventory",
                new String[]{"id", "item_name", "quantity"},
                null,
                null,
                null,
                null,
                "item_name ASC"
        );

        while (cursor.moveToNext()) {

            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            String itemName = cursor.getString(
                    cursor.getColumnIndexOrThrow("item_name"));
            int quantity = cursor.getInt(
                    cursor.getColumnIndexOrThrow("quantity"));

            addInventoryRow(id, itemName, quantity);
        }

        cursor.close();
        db.close();
    }

    private void showAddItemDialog() {

        EditText itemInput = new EditText(this);
        itemInput.setHint("Item name");

        EditText quantityInput = new EditText(this);
        quantityInput.setHint("Quantity");
        quantityInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);

        android.widget.LinearLayout layout = new android.widget.LinearLayout(this);
        layout.setOrientation(android.widget.LinearLayout.VERTICAL);
        layout.setPadding(32, 16, 32, 0);

        layout.addView(itemInput);
        layout.addView(quantityInput);

        new AlertDialog.Builder(this)
                .setTitle("Add Inventory Item")
                .setView(layout)
                .setPositiveButton("Add", (dialog, which) -> {

                    String itemName = itemInput.getText().toString().trim();
                    String quantityText = quantityInput.getText().toString().trim();

                    if (itemName.isEmpty() || quantityText.isEmpty()) {
                        return;
                    }

                    int quantity = Integer.parseInt(quantityText);

                    addInventoryItem(itemName, quantity);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void addInventoryItem(String itemName, int quantity) {

        SQLiteDatabase db = databaseHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("item_name", itemName);
        values.put("quantity", quantity);

        long result = db.insert("inventory", null, values);

        db.close();

        if (result != -1) {
            recreate();
        }
    }

    private void addInventoryRow(int id, String itemName, int quantity) {

        TableRow row = new TableRow(this);

        TextView itemText = new TextView(this);
        itemText.setText(itemName);
        itemText.setTextSize(16);
        itemText.setPadding(8, 8, 8, 8);

        TextView quantityText = new TextView(this);
        quantityText.setText(String.valueOf(quantity));
        quantityText.setTextSize(16);
        quantityText.setGravity(android.view.Gravity.CENTER);
        quantityText.setPadding(8, 8, 8, 8);

        Button decreaseButton = new Button(this);
        decreaseButton.setText("−");

        Button increaseButton = new Button(this);
        increaseButton.setText("+");

        Button deleteButton = new Button(this);
        deleteButton.setText("Delete");

        decreaseButton.setOnClickListener(v -> {
            if (quantity > 0) {
                updateInventoryQuantity(id, quantity - 1);
            }
        });


        increaseButton.setOnClickListener(v ->
                updateInventoryQuantity(id, quantity + 1));

        deleteButton.setOnClickListener(v ->
                deleteInventoryItem(id));

        row.addView(itemText);
        row.addView(quantityText);
        row.addView(decreaseButton);
        row.addView(increaseButton);
        row.addView(deleteButton);

        inventoryTable.addView(row);
    }

    private void updateInventoryQuantity(int id, int newQuantity) {

        SQLiteDatabase db = databaseHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("quantity", newQuantity);

        db.update(
                "inventory",
                values,
                "id = ?",
                new String[]{String.valueOf(id)}
        );

        String itemName = getItemName(id);

        db.close();

        if (newQuantity == 0) {
            sendLowInventoryAlert(itemName);
        }

        recreate();
    }

    private String getItemName(int id) {

        SQLiteDatabase db = databaseHelper.getReadableDatabase();

        Cursor cursor = db.query(
                "inventory",
                new String[]{"item_name"},
                "id = ?",
                new String[]{String.valueOf(id)},
                null,
                null,
                null
        );

        String itemName = "Unknown item";

        if (cursor.moveToFirst()) {
            itemName = cursor.getString(
                    cursor.getColumnIndexOrThrow("item_name"));
        }

        cursor.close();
        db.close();

        return itemName;
    }

    private void sendLowInventoryAlert(String itemName) {

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            Toast.makeText(
                    this,
                    "SMS permission is not enabled. Inventory will continue normally.",
                    Toast.LENGTH_LONG
            ).show();

            return;
        }

        String phoneNumber = "5551234567";

        String message =
                "Inventory Alert: " + itemName +
                        " has reached zero quantity.";

        SmsManager smsManager = SmsManager.getDefault();

        smsManager.sendTextMessage(
                phoneNumber,
                null,
                message,
                null,
                null
        );

        Toast.makeText(
                this,
                "Low inventory SMS alert sent.",
                Toast.LENGTH_SHORT
        ).show();
    }

    private void deleteInventoryItem(int id) {

        SQLiteDatabase db = databaseHelper.getWritableDatabase();

        db.delete(
                "inventory",
                "id = ?",
                new String[]{String.valueOf(id)}
        );

        db.close();

        recreate();
    }
}