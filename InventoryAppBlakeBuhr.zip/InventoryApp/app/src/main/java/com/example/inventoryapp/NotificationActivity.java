package com.example.inventoryapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class NotificationActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_REQUEST_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        Button allowNotificationsButton =
                findViewById(R.id.allowNotificationsButton);

        Button denyNotificationsButton =
                findViewById(R.id.denyNotificationsButton);

        allowNotificationsButton.setOnClickListener(v ->
                requestSmsPermission());

        denyNotificationsButton.setOnClickListener(v -> {
            Toast.makeText(this,
                    "SMS alerts disabled. The inventory app will continue to work.",
                    Toast.LENGTH_SHORT).show();

            finish();
        });
    }

    private void requestSmsPermission() {

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {

            Toast.makeText(this,
                    "SMS alerts are already enabled.",
                    Toast.LENGTH_SHORT).show();

            finish();

        } else {

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults) {

        super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {

            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                Toast.makeText(this,
                        "SMS alerts enabled.",
                        Toast.LENGTH_SHORT).show();

            } else {

                Toast.makeText(this,
                        "SMS permission denied. The inventory app will continue to work.",
                        Toast.LENGTH_LONG).show();
            }

            finish();
        }
    }
}