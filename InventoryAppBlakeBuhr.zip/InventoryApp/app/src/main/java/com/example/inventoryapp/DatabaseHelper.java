package com.example.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "InventoryApp.db";
    private static final int DATABASE_VERSION = 2;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Stores usernames and passwords for application login.
        db.execSQL("CREATE TABLE users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE NOT NULL, " +
                "password TEXT NOT NULL)");

        // Stores inventory items and their current quantities.
        db.execSQL("CREATE TABLE inventory (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "item_name TEXT UNIQUE NOT NULL, " +
                "quantity INTEGER NOT NULL)");

        // Add sample inventory items for initial testing.
        ContentValues cheezIts = new ContentValues();
        cheezIts.put("item_name", "Cheez-its");
        cheezIts.put("quantity", 25);
        db.insert("inventory", null, cheezIts);

        ContentValues pringles = new ContentValues();
        pringles.put("item_name", "Pringles");
        pringles.put("quantity", 5);
        db.insert("inventory", null, pringles);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS inventory");
        db.execSQL("DROP TABLE IF EXISTS users");
        onCreate(db);
    }
}