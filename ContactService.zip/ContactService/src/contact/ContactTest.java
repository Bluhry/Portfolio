package contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ContactTest {
	
	@Test
	void testContactIDNotUpdatable() {
		Contact contact = new Contact(
				"123",
				"Bill",
				"Billy",
				"1234567890",
				"12 street"
				);
		
		assertEquals("123", contact.getContactID());
	}
	
	@Test
	void testNullContactID() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact(
					null,
					"James",
					"Jamieson",
					"1234567890",
					"123 123 street"
					);
		});
	}

    @Test
    void testValidContactCreation() {

        Contact contact = new Contact(
                "545",
                "Blake",
                "Buhr",
                "7153099252",
                "1614 State Street"
        );

        assertEquals("545", contact.getContactID());
        assertEquals("Blake", contact.getFirstName());
        assertEquals("Buhr", contact.getLastName());
        assertEquals("7153099252", contact.getPhone());
        assertEquals("1614 State Street", contact.getAddress());
    }

    @Test
    void testInvalidContactID() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(
                    "19999998999",
                    "Bob",
                    "Jones",
                    "6124938308",
                    "123 5th Ave"
            );
        });
    }

    @Test
    void testNullFirstName() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(
                    "55555",
                    null,
                    "Billy",
                    "1234567890",
                    "122 15th Street"
            );
        });
    }

    @Test
    void testInvalidPhoneNumber() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(
                    "54510",
                    "Jack",
                    "Johnson",
                    "11111",
                    "1919 gary road"
            );
        });
    }

    @Test
    void testUpdateFirstName() {

        Contact contact = new Contact(
                "79645",
                "Jeremy",
                "Higgens",
                "1112223333",
                "123 North Street"
        );

        contact.setFirstName("James");

        assertEquals("James", contact.getFirstName());
    }

    @Test
    void testUpdateLastName() {

        Contact contact = new Contact(
                "65489",
                "Melvin",
                "Duder",
                "5556667896",
                "The West"
        );

        contact.setLastName("Sneedly");

        assertEquals("Sneedly", contact.getLastName());
    }

    @Test
    void testUpdatePhone() {

        Contact contact = new Contact(
                "64896",
                "Kevin",
                "Ronny",
                "5555555555",
                "Jill Avenue"
        );

        contact.setPhone("4444444444");

        assertEquals("4444444444", contact.getPhone());
    }

    @Test
    void testUpdateAddress() {

        Contact contact = new Contact(
                "64894",
                "Gary",
                "Giggles",
                "6879645621",
                "Middle of Nowhere"
        );

        contact.setAddress("195 Jerry Lane");

        assertEquals("195 Jerry Lane", contact.getAddress());
    }
}