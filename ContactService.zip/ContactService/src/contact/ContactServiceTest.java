package contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit .jupiter.api.Test;

public class ContactServiceTest {
	private ContactService service;
	
	@BeforeEach
	void setUp() {
		service = new ContactService();
	}
	
	@Test
	void testAddContact() {
		
		Contact contact = new Contact(
				"45678",
				"Jerry",
				"Mcguire",
				"6589421567",
				"1206 North Street"
				);
		
		service.addContact(contact);
		
		assertEquals("Jerry", service.getContact("45678").getFirstName());
	}
	
	@Test
	void testAddDuplicateContactID() {
		Contact firstContact = new Contact(
				"23",
				"Bill",
				"West",
				"9876543210",
				"South Street"
				);
		
		Contact secondContact = new Contact(
				"23",
				"Billy",
				"Wester",
				"4563217895",
				"Somewhere else");
		
		service.addContact(firstContact);
		
		assertThrows(IllegalArgumentException.class, () -> {
			service.addContact(secondContact);
		});		
	}
	@Test
	void testDeleteContact() {
		Contact contact = new Contact(
				"7",
				"Yes",
				"Man",
				"3959495061",
				"5th ave");
		
		service.addContact(contact);
		service.deleteContact("7");
		
		assertNull(service.getContact("7"));
	}
	
	@Test
	void testDeleteInvalidContact() {
		assertThrows(IllegalArgumentException.class, () -> {
			service.deleteContact("999");
		});
	}
	
	@Test
	void testUpdateFirstName() {
		
		Contact contact = new Contact(
				"9",
				"Someone",
				"New",
				"4568795456",
				"A place"
				);
		
		service.addContact(contact);
		service.updateFirstName("9", "Noone");
		
		assertEquals("Noone", service.getContact("9").getFirstName());
	}
	
	@Test
	void testUpdateLastName() {
		Contact contact = new Contact(
				"2",
				"Man",
				"Mcman",
				"6547891540",
				"A road somewhere"
				);
		
		service.addContact(contact);
		service.updateLastName("2", "Guy");
		
		assertEquals("Guy", service.getContact("2").getLastName());
	}
	
	 @Test
	    void testUpdatePhone() {

	        Contact contact = new Contact(
	                "11",
	                "Job",
	                "Done",
	                "4444444444",
	                "111 The Road"
	        );

	        service.addContact(contact);
	        service.updatePhone("11", "5555555555");

	        assertEquals("5555555555", service.getContact("11").getPhone());
	    }
	 
	 @Test
	    void testUpdateAddress() {

	        Contact contact = new Contact(
	                "52",
	                "Alex",
	                "Le",
	                "8976453120",
	                "Old Address"
	        );

	        service.addContact(contact);
	        service.updateAddress("52", "New Address");

	        assertEquals("New Address", service.getContact("52").getAddress());
	    }

	    @Test
	    void testUpdateNonexistentContact() {

	        assertThrows(IllegalArgumentException.class, () -> {
	            service.updateFirstName("999", "Nobody");
	        });
	    }
}
