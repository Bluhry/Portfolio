// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>

// Custom exception derived from std::exception
class CustomException : public std::exception {
public:
    const char* what() const noexcept override
    {
        return "A custom application exception occurred.";
    }
};

bool do_even_more_custom_application_logic()
{
    //Throw any standard exception

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    throw std::runtime_error("Even more custom application logic failed.");

    return true;
}
void do_custom_application_logic()
{
    // Catch standard exceptions thrown by additional application logic
    std::cout << "Running Custom Application Logic." << std::endl;

    try
    {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e)
    {
        std::cout << "Standard exception caught: " << e.what() << std::endl;
    }

    // Throw a custom exception that will be handled in main 
    throw CustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // Prevent division by zero by throwing a standard C++ exception
    if (den == 0.0f) {
        throw std::runtime_error("Cant divide by zero.");
    }
    return (num / den);
}

void do_division() noexcept
{
    // create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0;
    
    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::runtime_error& e) {
        std::cout << "Division exception caught: " << e.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.
    try {
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomException& e) {
        std::cout << "Custom exception caught: " << e.what() << std::endl;
    }
    catch (const std::exception& e) {
        std::cout << "Standard exception caught in main: " << e.what() << std::endl;
    }
    catch (...) {
        std::cout << "An unknown exception was caught in main." << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu